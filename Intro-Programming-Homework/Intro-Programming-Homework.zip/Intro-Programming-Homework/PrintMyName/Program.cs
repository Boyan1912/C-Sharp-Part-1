﻿using System;


namespace PrintMyName
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("This is my name.");
        }
    }
}
