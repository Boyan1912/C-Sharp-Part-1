﻿using System;


namespace Print_First_and_Last_Name
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("My First Name");
            Console.WriteLine("My Last Name");
        }
    }
}
