﻿
namespace Problem3VariableInHexadecimalFormat
{
    using System;
    class Problem3VariableInHexadecimalFormat
    {
        static void Main()
        {
            int variable = 0xFE;
            Console.WriteLine(variable);
        }
    }
}
