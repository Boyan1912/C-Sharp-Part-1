﻿namespace Problem8IsoscelesTriangle
{
    using System;
    using System.Text;
    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("   ©");
            Console.WriteLine("  © ©");
            Console.WriteLine(" ©   ©");
            Console.WriteLine("© © © ©");
        }
    }
}
