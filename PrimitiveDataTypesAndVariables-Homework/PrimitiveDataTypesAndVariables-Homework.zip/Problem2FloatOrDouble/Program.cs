﻿

namespace Problem2FloatOrDouble
{
    using System;
    class Problem2FloatOrDouble
    {
        static void Main()
        {
            double firstNumber = 34.567839023;
            float secondNumber = 12.345f;
            double thirdNumber = 8923.1234857;
            float fourthNumber = 3456.091f;

            Console.Write("{0}, {1}, {2}, {3}", firstNumber, secondNumber, thirdNumber, fourthNumber);
        }
    }
}
