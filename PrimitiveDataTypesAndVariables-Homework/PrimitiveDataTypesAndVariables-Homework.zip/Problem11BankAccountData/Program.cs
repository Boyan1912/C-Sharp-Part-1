﻿namespace Problem11BankAccountData
{
    using System;
    class Program
    {
        static void Main()
        {
            string firstName;
            string middleName;
            string lastName;
            int balance;
            long accountIBAN;
            long firstCreditCard;
            long secondCreditCard;
            long thirdCreditCard;
        }
    }
}
