﻿
namespace Problem5BooleanVariable
{
    using System;
    class Program
    {
        
        static void Main()
        {
            bool isFemale = false;
            Console.WriteLine(isFemale);
        }
    }
}
