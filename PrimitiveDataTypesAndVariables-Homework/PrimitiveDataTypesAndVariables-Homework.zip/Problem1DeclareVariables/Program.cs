﻿


namespace Problem1DeclareVariables
{
    using System;
    class DeclareVariables
    {
        static void Main(string[] args)
        {
            ushort firstNumber = 52130;
            sbyte secondNumber = -115;
            int thirdNumber = 4825932;
            byte fourthNumber = 97;
            short fifthNumber = -10000;
        }
    }
}
