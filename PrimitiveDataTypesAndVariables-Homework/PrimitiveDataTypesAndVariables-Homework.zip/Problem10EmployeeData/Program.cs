﻿
namespace Problem10EmployeeData
{
    using System;
    class Program
    {
        static void Main()
        {
            string firstName = "Pesho";
            string lastName = "Peshov";
            byte age = 32;
            char gender = 'm';
            long personalIDNumber = 8306112507;
            int employeeNumber = 27560000;

            Console.WriteLine("{0}\n{1}\n{2}\n{3}\n{4}\n{5}", firstName, lastName, age, gender, personalIDNumber, employeeNumber);
        }
    }
}
